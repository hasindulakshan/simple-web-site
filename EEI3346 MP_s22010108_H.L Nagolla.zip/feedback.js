const app = new Vue({
    el: '#feedback-form',
    data: {
        name: '',
        email: '',
        message: '',
    },
    methods: {
        submitForm() {

            axios.post('/api/feedback', {
                name: this.name,
                email: this.email,
                message: this.message,
            })
                .then(response => {
                    console.log(response.data);
                    alert('Thank you for your feedback!');
                })
                .catch(error => {
                    console.log(error);
                    alert('Error submitting feedback.');
                });
        },
    },
});